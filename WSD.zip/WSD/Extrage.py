import numpy as np
import matplotlib.pyplot as plt
#https://matplotlib.org/gallery/shapes_and_collections/scatter.html#sphx-glr-gallery-shapes-and-collections-scatter-py

# f=open("1554098630.2730103","r")
f=open("1554023081.0104618","r")
# f=open("q.txt","r")
Lines=f.readlines()
LinesNumere=[L.split('[')[0] for L in Lines]
LinesFunctii=[L.split('[')[1] for L in Lines]


LinesNumere=np.array([L.replace('time:','').split() for L in LinesNumere],dtype=float)


Acc=LinesNumere[:,0]
Timp=LinesNumere[:,1]
Fereastra=LinesNumere[:,2]
MinPgrama=LinesNumere[:,3]
MaxPgrama=LinesNumere[:,4]

plt.scatter(Acc, Timp)
plt.show()