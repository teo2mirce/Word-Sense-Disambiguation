import signal
#cel mai important import

import numpy as np
import nltk
from collections import Counter
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize

sentence="w7_010:888: <s> The company argued that its foreman needn't have told the worker not to move the plank to which his lifeline was tied because \"that comes with common sense.\" </s> @ </p> @ <p> @ <s> The commission noted, however, that Dellovade hadn't instructed its employees on how to secure their lifelines and didn't heed a federal inspector's earlier suggestion that the company install special safety lines inside the A-frame structure it was building. </s>"

#https://pythonspot.com/nltk-stemming/
ps = PorterStemmer()


#http://www.nltk.org/howto/wordnet.html
from nltk.corpus import wordnet as wn



# probabil e util https://pythonprogramming.net/wordnet-nltk-tutorial/
# tre scoasa lista de functii de similaritate
# http://www.nltk.org/_modules/nltk/corpus/reader/wordnet.html   gen: lch_similarity



from nltk.corpus import senseval
# line corpus: http://www.nltk.org/howto/corpus.html
# len(senseval.instances('line.pos'))




# Map pentru hard https://stackoverflow.com/questions/16381218/how-do-i-get-the-definition-for-a-sense-in-nltks-senseval-module
# baiatu asta merita o bere
# A map of SENSEVAL senses to WordNet 3.0 senses.
# SENSEVAL-2 uses WordNet 1.7, which is no longer installable on most modern
# machines and is not the version that the NLTK comes with.
# As a consequence, we have to manually map the following
# senses to their equivalent(s).
# SV_SENSE_MAP = {
    # "HARD1": ["difficult.a.01"],    # not easy, requiring great physical or mental
    # "HARD2": ["hard.a.02",          # dispassionate
              # "difficult.a.01"],
    # "HARD3": ["hard.a.03"],         # resisting weight or pressure
	
	
    # "interest_1": ["interest.n.01"], # readiness to give attention
    # "interest_2": ["interest.n.03"], # quality of causing attention to be given to
    # "interest_3": ["pastime.n.01"],  # activity, etc. that one gives attention to
    # "interest_4": ["sake.n.01"],     # advantage, advancement or favor
    # "interest_5": ["interest.n.05"], # a share in a company or business
    # "interest_6": ["interest.n.04"], # money paid for the use of money
    
	# "cord": ["line.n.18"],          # something (as a cord or rope) that is long and thin and flexible
    # "formation": ["line.n.01","line.n.03"], # a formation of people or things one beside another
    # "text": ["line.n.05"],                 # text consisting of a row of words written across a page or computer screen
    # "phone": ["telephone_line.n.02"],   # a telephone connection
    # "product": ["line.n.22"],       # a particular kind of product or merchandise
    # "division": ["line.n.29"],      # a conceptual separation or distinction
    
	# "SERVE12": ["serve.v.02"],       # do duty or hold offices; serve in a specific function
    # "SERVE10": ["serve.v.06"], # provide (usually but not necessarily food)
    # "SERVE2": ["serve.v.01"],       # serve a purpose, role, or function
    # "SERVE6": ["service.v.01"]      # be used by; as of a utility
# }

MapLine={
	"line.n.18": "cord",
	"line.n.01": "formation",
	"line.n.03": "formation",
	"line.n.05": "text",
	"telephone_line.n.02": "phone",
	"line.n.22": "product",
	"line.n.29": "division",
}







from nltk.corpus import stopwords
stop_words = stopwords.words('english')
#https://chrisalbon.com/machine_learning/preprocessing_text/remove_stop_words/

def Text2Pgrams(text,pgram):

	
	temp=Counter(['_'.join(text[i:i + pgram]) for i in range(0, len(text )-pgram +1 )])
	
	# norma=1+sum(temp.values())
	# for pair in temp.keys():
		# temp[pair]/=norma
					
	return temp
	

def KernelFrom2Lists(A,B):
	ret=0
	if(len(A)<len(B)):
		for pair in A.keys():
			if(B[pair]!=0):
				ret+=B[pair]+A[pair]
	else:
		for pair in B.keys():
			if(A[pair]!=0):
				ret+=B[pair]+A[pair]
	return ret
def Similaritate(A,B):
	ret=0
	for i in range(1,5):
		k=KernelFrom2Lists(Text2Pgrams(A,i),Text2Pgrams(B,i))
		ret+=k*i**2
		if(k==0):
			i=9999
	return ret
	
#Similaritate("paper specific prepared for use in drawing","art of transforming design from specific prepared paper")
#7
import time

def ConcatWordsDefinitionsAndExamples(Words):
	ret=''
	for word in Words:
		for syn in wn.synsets(word):
			ret+=' '+syn.definition()+' '+(' '.join(syn.examples()))
	return ret

def CleanString(text):
	text=text.split()
	text=[word for word in text if word not in stop_words]
	
	# text=[ps.stem(word) for word in text if len(wn.synsets(word))!=0]#keep words with sense, and apply stemmin'
	return text
	
def StringVsSynsets(Str,Syns):

	TipCuvant=Linie.word.split('-')[1]
	
	
	WordsWithSense=[word[0] for word in Str.context if len(wn.synsets(word[0]))!=0]
	LineIndex= [ps.stem(word) for word in WordsWithSense].index('line')
	Context=[word for word in WordsWithSense[LineIndex-3:LineIndex+3 +1] if ps.stem(word)!=ps.stem('line')]
	Str=ConcatWordsDefinitionsAndExamples(Context)
	
	
	GoodSyns=[syn for syn in Syns   if syn.name().split('.')[1] == TipCuvant]
	
	
	Similar=[Similaritate(CleanString(Str), CleanString(syn.definition()+' '+(' '.join(syn.examples())) 	)) for syn in GoodSyns]
	
	indexSyn=np.argmax(Similar)
	
	return GoodSyns[indexSyn].name()

# [i.senses for i in senseval.instances('line.pos') if len(i.senses)!=1]  toate au un singur sens




#sanity check

# Str="Such a trading strategy would ordinarily be a prescription for instant losses. </s> @ <s> But the trader says he was merely following instructions from his client -- a Fed dealer on the other end of a dedicated private telephone line."
# Words=word_tokenize(Str)
# WordsWithSense=[word for word in Words if len(wn.synsets(word[0]))!=0]
# LineIndex= [ps.stem(word) for word in WordsWithSense].index('line')
# Context=[word for word in WordsWithSense[LineIndex-3:LineIndex+3 +1] if ps.stem(word)!=ps.stem('line')]
# Str=ConcatWordsDefinitionsAndExamples(Context)
# GoodSyns=[syn for syn in wn.synsets('line')   if syn.name().split('.')[1] == 'n']
# Similar=[Similaritate(Str, syn.definition()+' '+(' '.join(syn.examples())) 	) for syn in GoodSyns]
# indexSyn=np.argmax(Similar)

# TelSyn=GoodSyns[14]
# STRSYN=TelSyn.definition()+' '+(' '.join(TelSyn.examples()))

# AltuSyn=GoodSyns[0]
# STRSYN2=AltuSyn.definition()+' '+(' '.join(AltuSyn.examples()))


# Similaritate(Str,STRSYN)
# Similaritate(Str,STRSYN2)

# exit(0)











Cate=len(senseval.instances('line.pos'))
toate=0
bune=0
start_time = time.time()
nrLinii=len(senseval.instances('line.pos'))
for Linie in senseval.instances('line.pos'):
	index=StringVsSynsets(Linie,wn.synsets('line'))
	
	pred='gresit'
	if index in MapLine:
		pred=MapLine[index]
	# print(100.0*i/Cate,'% ',Linie.senses[0],'->',pred)
	if(Linie.senses[0]==pred):
		bune+=1
	toate+=1
	print(round(100.0*toate/nrLinii),'% done ,time:',time.time() - start_time,' ',Linie.senses[0],'->',pred,' acc: ',100.0*bune/toate)
# Linie1=senseval.instances('line.pos')[0]



'''
Create a Synset from a "<lemma>.<pos>.<number>" string where:
<lemma> is the word's morphological stem
<pos> is one of the module attributes ADJ, ADJ_SAT, ADV, NOUN or VERB
<number> is the sense number, counting from 0.

Synset attributes, accessible via methods with the same name:

- name: The canonical name of this synset, formed using the first lemma
  of this synset. Note that this may be different from the name
  passed to the constructor if that string used a different lemma to
  identify the synset.
- pos: The synset's part of speech, matching one of the module level
  attributes ADJ, ADJ_SAT, ADV, NOUN or VERB.
- lemmas: A list of the Lemma objects for this synset.
- definition: The definition for this synset.
- examples: A list of example strings for this synset.
- offset: The offset in the WordNet dict file of this synset.
- lexname: The name of the lexicographer file containing this synset.

Synset methods:

Synsets have the following methods for retrieving related Synsets.
They correspond to the names for the pointer symbols defined here:
http://wordnet.princeton.edu/man/wninput.5WN.html#sect3
These methods all return lists of Synsets.

- hypernyms, instance_hypernyms
- hyponyms, instance_hyponyms
- member_holonyms, substance_holonyms, part_holonyms
- member_meronyms, substance_meronyms, part_meronyms
- attributes
- entailments
- causes
- also_sees
- verb_groups
- similar_tos

Additionally, Synsets support the following methods specific to the
hypernym relation:

- root_hypernyms
- common_hypernyms
- lowest_common_hypernyms

Note that Synsets do not support the following relations because
these are defined by WordNet as lexical relations:

- antonyms
- derivationally_related_forms
- pertainyms
'''