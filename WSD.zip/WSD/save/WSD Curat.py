import signal
import time
import re
import numpy as np
import nltk
from collections import Counter
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import wordnet as wn
from nltk.corpus import senseval
from nltk.corpus import wordnet_ic
from nltk.corpus import stopwords
stop_words = stopwords.words('english')
ps = PorterStemmer()





# SV_SENSE_MAP = {
    # "HARD1": ["difficult.a.01"],    # not easy, requiring great physical or mental
    # "HARD2": ["hard.a.02",          # dispassionate
              # "difficult.a.01"],
    # "HARD3": ["hard.a.03"],         # resisting weight or pressure
	
	
    # "interest_1": ["interest.n.01"], # readiness to give attention
    # "interest_2": ["interest.n.03"], # quality of causing attention to be given to
    # "interest_3": ["pastime.n.01"],  # activity, etc. that one gives attention to
    # "interest_4": ["sake.n.01"],     # advantage, advancement or favor
    # "interest_5": ["interest.n.05"], # a share in a company or business
    # "interest_6": ["interest.n.04"], # money paid for the use of money
    
	# "cord": ["line.n.18"],          # something (as a cord or rope) that is long and thin and flexible
    # "formation": ["line.n.01","line.n.03"], # a formation of people or things one beside another
    # "text": ["line.n.05"],                 # text consisting of a row of words written across a page or computer screen
    # "phone": ["telephone_line.n.02"],   # a telephone connection
    # "product": ["line.n.22"],       # a particular kind of product or merchandise
    # "division": ["line.n.29"],      # a conceptual separation or distinction
    
	# "SERVE12": ["serve.v.02"],       # do duty or hold offices; serve in a specific function
    # "SERVE10": ["serve.v.06"], # provide (usually but not necessarily food)
    # "SERVE2": ["serve.v.01"],       # serve a purpose, role, or function
    # "SERVE6": ["service.v.01"]      # be used by; as of a utility
# }

MapLine={
	"line.n.18": "cord",
	"line.n.01": "formation",
	"line.n.03": "formation",
	"line.n.05": "text",
	"telephone_line.n.02": "phone",
	"line.n.22": "product",
	"line.n.29": "division",
}





gloss_rel = lambda x: x.definition()
example_rel = lambda x: " ".join(x.examples())
hyponym_rel = lambda x: " ".join(w.definition() for w in x.hyponyms())
meronym_rel = lambda x: " ".join(w.definition() for w in x.member_meronyms() + \
                                 x.part_meronyms() + x.substance_meronyms())
also_rel = lambda x: " ".join(w.definition() for w in x.also_sees())
attr_rel = lambda x: " ".join(w.definition() for w in x.attributes())
hypernym_rel = lambda x: " ".join(w.definition() for w in x.hypernyms())

relpairs = {wn.NOUN: [(hyponym_rel, meronym_rel), (meronym_rel, hyponym_rel),
                      (hyponym_rel, hyponym_rel),
                      (gloss_rel, meronym_rel), (meronym_rel, gloss_rel),
                      (example_rel, meronym_rel), (meronym_rel, example_rel),
                      (gloss_rel, gloss_rel)],
            wn.ADJ: [(also_rel, gloss_rel), (gloss_rel, also_rel),
                     (attr_rel, gloss_rel), (gloss_rel, attr_rel),
                     (gloss_rel, gloss_rel),
                     (example_rel, gloss_rel), (gloss_rel, example_rel),
                     (gloss_rel, hypernym_rel), (hypernym_rel, gloss_rel)],
            wn.VERB:[(example_rel, example_rel),
                     (example_rel, hypernym_rel), (hypernym_rel, example_rel),
                     (hyponym_rel, hyponym_rel),
                     (gloss_rel, hyponym_rel), (hyponym_rel, gloss_rel),
                     (example_rel, gloss_rel), (gloss_rel, example_rel)]}

def preprocess(text):
    '''
    Helper function to preprocess text (lowercase, remove punctuation etc.)
    '''
    words = re.split('\s+', text)
    punctuation = re.compile(r'[-.?!,":;()|0-9]')
    words = [punctuation.sub("", word) for word in words]
    words = filter(None, words)
    words = [word.lower() for word in words]
    words = [word for word in words if not word in stopwords.words('english')]
    return words

def lcs(S1, S2):
    # print("LCS1: ",S1)
    # print("LCS2: ",S2)
    '''
    Helper function to compute length and offsets of longest common substring of
    S1 and S2. Uses the classical dynamic programming algorithm.
    Shamelessly copied off Wikibooks.
    '''
    M = [[0]*(1+len(S2)) for i in range(1+len(S1))]
    longest, x_longest, y_longest = 0, 0, 0
    for x in range(1,1+len(S1)):
        for y in range(1,1+len(S2)):
            if S1[x-1] == S2[y-1]:
                M[x][y] = M[x-1][y-1] + 1
                if M[x][y]>longest:
                    longest = M[x][y]
                    x_longest = x
                    y_longest = y
            else:
                M[x][y] = 0
    return longest, x_longest - longest, y_longest - longest

def score(gloss1, gloss2):
    '''
    Compute score between two glosses based on length of common substrings.
    '''
    gloss1 = preprocess(gloss1)
    gloss2 = preprocess(gloss2)
    curr_score = 0
    longest, start1, start2, = lcs(gloss1, gloss2)
    while longest > 0:
        gloss1[start1 : start1 + longest] = []
        gloss2[start2 : start2 + longest] = []
        curr_score += longest ** 2
        longest, start1, start2, = lcs(gloss1, gloss2)
    return curr_score

def relatedness(sense1, sense2, relpairs):
    '''
    Compute the relatedness of two senses (synsets) using the list of pairs of
    relations in relpairs.
    '''
    return sum(score(pair[0](sense1), pair[1](sense2)) for pair in relpairs)

# def wsd(context, target, winsize, pos_tag):
def wsd(context, target_synsets, winsize, pos_tag):
    '''
    Find the best sense for a word in a given context.

    Arguments:
    context - sentence(s) we are analyzing; expected as list of strings
    target  - string representing the word whose senses we're trying to
              disambiguate. Target is assumed to occur once in sentence. In case
              of multiple occurences, the first one is considered. Will throw
              ValueError if target is not in sentence
    winsize - size of window used for disambiguating. The algorithm will only
              look at winsize words of the appropriate part-of-speech around the
              target word
    pos_tag - part of speech of target word
    '''
    context = list(filter(None, [wn.synsets(word) for word in context]))
	
    # target_synsets = wn.synsets(target, pos=pos_tag)
	
	
    pos = context.index(  wn.synsets("line")  )
    window = context[max(pos - winsize, 0) : pos] + \
             context[pos + 1 : min(pos + winsize + 1, len(context))]
    sense_scores = [sum(sum(relatedness(sense, other_sense, relpairs[pos_tag])
                              for other_sense in senses)
                   for senses in window) for sense in target_synsets]
    best_score = max(sense_scores)
    best_index = sense_scores.index(best_score)
	
    return target_synsets[best_index], best_score







start_time = time.time()

# sentence = "I went fishing for some sea bass"
# sentence = preprocess(sentence)
# sense, scor = wsd(sentence, "bass", 3, wn.NOUN)
# print (scor,' ', sense,' ', sense.definition())


nrLinii=len(senseval.instances('line.pos'))
synseturi=wn.synsets('line')
synseturi=[syn for syn in synseturi if syn.name() in MapLine]
toate=0
bune=0
for Linie in senseval.instances('line.pos'):
	
	sentence=' '.join([x[0] for x in Linie.context])
	sentence = preprocess(sentence)
	sense, scor = wsd(sentence, synseturi, 3, wn.NOUN)
	
	index=sense.name()
	pred='gresit ('+index+')'
	if index in MapLine:
		pred=MapLine[index]
	# print(100.0*i/Cate,'% ',Linie.senses[0],'->',pred)
	if(Linie.senses[0]==pred):
		bune+=1
	toate+=1
	#if(toate%400==0):
	print(round(100.0*toate/nrLinii),'% done ,time:',time.time() - start_time,' ',Linie.senses[0],'->',pred,' acc: ',100.0*bune/toate)
print(round(100.0*toate/nrLinii),'% done ,time:',time.time() - start_time,' ',Linie.senses[0],'->',pred,' acc: ',100.0*bune/toate)




exit(0)











def Text2Pgrams(text,pgram):
	temp=Counter([text[i:i + pgram] for i in range(0, len(text )-pgram +1 )])
	return temp
	

def KernelFrom2Lists(A,B):
	ret=0
	if(len(A)<len(B)):
		for pair in A.keys():
			if(B[pair]!=0):
				ret+=B[pair]+A[pair]
	else:
		for pair in B.keys():
			if(A[pair]!=0):
				ret+=B[pair]+A[pair]
	return ret
def Similaritate(A,B):
	ret=0
	for i in range(1,5):
		k=KernelFrom2Lists(Text2Pgrams(A,i),Text2Pgrams(B,i))
		ret+=k*i**2
		if(k==0):
			i=9999
	return ret	



def ConcatWordsDefinitionsAndExamples(Words):
	ret=''
	for word in Words:
		for syn in wn.synsets(word):
			ret+=' '+syn.definition()+' '+(' '.join(syn.examples()))
	return ret

	


def CleanString(text):
	text=text.split()
	text=[word.lower() for word in text if word not in stop_words]
	text=[word for word in text if len(wn.synsets(word))!=0]#keep words with sense, and apply stemmin'
	return text
	
def POSFromName(q):
	return q.name().split('.')[1]
	

	
	
	
	



def StringVsSynsets(Str,Syns,FMMM,FSimilar):

	TipCuvant=Linie.word.split('-')[1]
	
	
	WordsWithSense=[word[0] for word in Str.context if len(wn.synsets(word[0]))!=0]
	LineIndex= [ps.stem(word) for word in WordsWithSense].index('line')
	Context=[word for word in WordsWithSense[LineIndex-3:LineIndex+3 +1] if ps.stem(word)!=ps.stem('line')]
	
	SynseturiContext=[]
	for word in Context:
		for syn in wn.synsets(word):
			SynseturiContext.append(syn)
			
	GoodSyns=[syn for syn in Syns   if syn.name().split('.')[1] == TipCuvant]		
	
	distances=[]
	for syn in GoodSyns:
		SynsetLinie=[syn]+syn.hyponyms()+syn.hypernyms()
		distances.append(DistanceFrom2ListOfSynset(SynseturiContext,SynsetLinie,FMMM,FSimilar))
	indexSyn=np.argmax(distances)
	
	# Str=ConcatWordsDefinitionsAndExamples(Context)
	# 
	# Similar=[Similaritate(CleanString(Str), CleanString(syn.definition()+' '+(' '.join(syn.examples())) 	)) for syn in GoodSyns]
	# indexSyn=np.argmax(Similar)
	
	return GoodSyns[indexSyn].name()



	
	

nrLinii=len(senseval.instances('line.pos'))
synseturi=wn.synsets('line')
# synseturi=[syn for syn in synseturi if syn.name() in MapLine]
toate=0
bune=0
for Linie in senseval.instances('line.pos'):
	
	index=StringVsSynsets(Linie,synseturi,FMMM,FSimilar)
	
	pred='gresit'
	if index in MapLine:
		pred=MapLine[index]
	# print(100.0*i/Cate,'% ',Linie.senses[0],'->',pred)
	if(Linie.senses[0]==pred):
		bune+=1
	toate+=1
	if(toate%400==0):
		print(round(100.0*toate/nrLinii),'% done ,time:',time.time() - start_time,' ',Linie.senses[0],'->',pred,' acc: ',100.0*bune/toate)
print(round(100.0*toate/nrLinii),'% done ,time:',time.time() - start_time,' ',Linie.senses[0],'->',pred,' acc: ',100.0*bune/toate)



