import signal
#cel mai important import

import numpy as np
import nltk
from collections import Counter
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize

sentence="w7_010:888: <s> The company argued that its foreman needn't have told the worker not to move the plank to which his lifeline was tied because \"that comes with common sense.\" </s> @ </p> @ <p> @ <s> The commission noted, however, that Dellovade hadn't instructed its employees on how to secure their lifelines and didn't heed a federal inspector's earlier suggestion that the company install special safety lines inside the A-frame structure it was building. </s>"

#https://pythonspot.com/nltk-stemming/
ps = PorterStemmer()


#http://www.nltk.org/howto/wordnet.html
from nltk.corpus import wordnet as wn



# probabil e util https://pythonprogramming.net/wordnet-nltk-tutorial/
# tre scoasa lista de functii de similaritate
# http://www.nltk.org/_modules/nltk/corpus/reader/wordnet.html   gen: lch_similarity



from nltk.corpus import senseval
# line corpus: http://www.nltk.org/howto/corpus.html
# len(senseval.instances('line.pos'))


# https://github.com/NehaNayak/fallMonotonicity/blob/master/wordnetClustered/data/ambiguous_location_wn3.txt


# Map pentru hard https://stackoverflow.com/questions/16381218/how-do-i-get-the-definition-for-a-sense-in-nltks-senseval-module
# baiatu asta merita o bere
# A map of SENSEVAL senses to WordNet 3.0 senses.
# SENSEVAL-2 uses WordNet 1.7, which is no longer installable on most modern
# machines and is not the version that the NLTK comes with.
# As a consequence, we have to manually map the following
# senses to their equivalent(s).
# SV_SENSE_MAP = {
    # "HARD1": ["difficult.a.01"],    # not easy, requiring great physical or mental
    # "HARD2": ["hard.a.02",          # dispassionate
              # "difficult.a.01"],
    # "HARD3": ["hard.a.03"],         # resisting weight or pressure
	
	
    # "interest_1": ["interest.n.01"], # readiness to give attention
    # "interest_2": ["interest.n.03"], # quality of causing attention to be given to
    # "interest_3": ["pastime.n.01"],  # activity, etc. that one gives attention to
    # "interest_4": ["sake.n.01"],     # advantage, advancement or favor
    # "interest_5": ["interest.n.05"], # a share in a company or business
    # "interest_6": ["interest.n.04"], # money paid for the use of money
    
	# "cord": ["line.n.18"],          # something (as a cord or rope) that is long and thin and flexible
    # "formation": ["line.n.01","line.n.03"], # a formation of people or things one beside another
    # "text": ["line.n.05"],                 # text consisting of a row of words written across a page or computer screen
    # "phone": ["telephone_line.n.02"],   # a telephone connection
    # "product": ["line.n.22"],       # a particular kind of product or merchandise
    # "division": ["line.n.29"],      # a conceptual separation or distinction
    
	# "SERVE12": ["serve.v.02"],       # do duty or hold offices; serve in a specific function
    # "SERVE10": ["serve.v.06"], # provide (usually but not necessarily food)
    # "SERVE2": ["serve.v.01"],       # serve a purpose, role, or function
    # "SERVE6": ["service.v.01"]      # be used by; as of a utility
# }

MapLine={
	"line.n.18": "cord",
	"line.n.01": "formation",
	"line.n.05": "text",
	"telephone_line.n.02": "phone",
	"line.n.22": "product",
	"line.n.29": "division",
}



#http://www.nltk.org/howto/wordnet.html
from nltk.corpus import wordnet_ic
semcor_ic = wordnet_ic.ic('ic-semcor.dat')
brown_ic = wordnet_ic.ic('ic-brown.dat')






from nltk.corpus import stopwords
stop_words = stopwords.words('english')
#https://chrisalbon.com/machine_learning/preprocessing_text/remove_stop_words/

def Text2Pgrams(text,pgram):

	
	temp=Counter(text[i:i + pgram] for i in range(0, len(text )-pgram +1 ))
	
	norma=1+sum(temp.values())
	for pair in temp.keys():
		temp[pair]/=norma
					
	return temp
	

def KernelFrom2Lists(A,B):
	ret=0
	if(len(A)<len(B)):
		for pair in A.keys():
			if(B[pair]!=0):
				ret+=B[pair]+A[pair]
	else:
		for pair in B.keys():
			if(A[pair]!=0):
				ret+=B[pair]+A[pair]
	return ret
def Similaritate(A,B,pgram_start,pgram_end):
	ret=0
	# for i in range(1,13):
	for i in range(pgram_start,pgram_end):
		k=KernelFrom2Lists(Text2Pgrams(A,i),Text2Pgrams(B,i))
		ret+=k*i**2
		if(k==0):
			i=9999
	return ret	
#idei: daca un cuvant e mai obscur, are importanta mai mare (telephone) ca se gaseste in ambele glose ifidf
#sinonime  https://stackoverflow.com/questions/42446521/check-whether-there-is-any-synonyms-between-two-word-sets/42474691
#poate https://github.com/DistrictDataLabs/intro-to-nltk/blob/master/exercises/preprocess/evaluate.py

#Similaritate("paper specific prepared for use in drawing","art of transforming design from specific prepared paper")
#7
import time
import string
def CleanStringFromContext(Words,relatii):
	ret=' '.join(Words)+' '
	for word in Words:
		for syn in wn.synsets(word):
			ret+=' '+CleanStringFromSynset(syn,relatii)
	return ret

	

ReadLines=open("Line.csv").readlines()
ReadLines.pop(0)
ReadLines=[R.split(',')[1].replace("\"","") for R in ReadLines]
CuvinteLegateDeLinii=[R.lower() for R in ReadLines if R.isalpha()]

def CleanString(text):
	text=text.translate(text.maketrans('', '', string.punctuation))
	text=text.split()
	text=[word.lower() for word in text if word not in stop_words]
	
	
	text=[word for word in text if word in CuvinteLegateDeLinii]
	#poate merge si not in?
	#text=[word for word in text if word not in CuvinteLegateDeLinii]
	
	# text=[ps.stem(word) for word in text if len(wn.synsets(word))!=0]#keep words with sense, and apply stemmin'
	return text
	
def POSFromName(q):
	return q.name().split('.')[1]

	
def DistanceFrom2ListOfSynset(A,B,FMMM,FSimilar):
	ret=[]
	for a in A:
		for b in B:
			if(POSFromName(a)==POSFromName(b)):
				dist=FSimilar(a,b)
				if dist!=None:
					ret.append(dist)
	return FMMM(ret)

def StringVsSynsets(Str,Syns,FMMM,FSimilar):

	TipCuvant=Linie.word.split('-')[1]
	
	
	WordsWithSense=[word[0] for word in Str.context if len(wn.synsets(word[0]))!=0]
	LineIndex= [ps.stem(word) for word in WordsWithSense].index('line')
	Context=[word for word in WordsWithSense[LineIndex-3:LineIndex+3 +1] if ps.stem(word)!=ps.stem('line')]
	
	SynseturiContext=[]
	for word in Context:
		for syn in wn.synsets(word):
			SynseturiContext.append(syn)
			
	GoodSyns=[syn for syn in Syns   if syn.name().split('.')[1] == TipCuvant]		
	
	distances=[]
	for syn in GoodSyns:
		SynsetLinie=[syn]+syn.hyponyms()+syn.hypernyms()
		distances.append(DistanceFrom2ListOfSynset(SynseturiContext,SynsetLinie,FMMM,FSimilar))
	indexSyn=np.argmax(distances)
	
	# Str=ConcatWordsDefinitionsAndExamples(Context)
	# 
	# Similar=[Similaritate(CleanString(Str), CleanString(syn.definition()+' '+(' '.join(syn.examples())) 	)) for syn in GoodSyns]
	# indexSyn=np.argmax(Similar)
	
	return GoodSyns[indexSyn].name()

# [i.senses for i in senseval.instances('line.pos') if len(i.senses)!=1]  toate au un singur sens

SinseturiLinie=wn.synsets('line')
SinseturiLinie=[syn for syn in SinseturiLinie if syn.name() in MapLine]




def definition(x):
	return x.definition()
def examples(x):
	return " ".join(x.examples())
def hyponyms(x):
	return " ".join(w.definition() for w in x.hyponyms())
def hypernyms(x):
	return " ".join(w.definition() for w in x.hypernyms())
def member_meronyms(x):
	return " ".join(w.definition() for w in x.member_meronyms())
def part_meronyms(x):
	return " ".join(w.definition() for w in x.part_meronyms())
def substance_meronyms(x):
	return " ".join(w.definition() for w in x.substance_meronyms())
def also_sees(x):
	return " ".join(w.definition() for w in x.also_sees())
def attributes(x):
	return " ".join(w.definition() for w in x.attributes())


relations=[definition,examples,hyponyms,hypernyms,member_meronyms,part_meronyms,substance_meronyms,also_sees,attributes]


import itertools
def findsubsets(S,m):
    return set(itertools.combinations(S, m))


def CleanStringFromSynset(syn,relatii):
	ret = ''
	for rel in relatii:
		ret+=' '+rel(syn)
	return  ' '.join(CleanString(ret))

#sanity check

#https://corpora.linguistik.uni-erlangen.de/cgi-bin/demos/Web1T5/Web1T5_colloc.perl?query=line&mode=Search&method=t&span_left=4&span_right=4&limit=1000&threshold=40&span_distribution=on&.cgifields=debug&.cgifields=span_distribution
#Google^


start_time = time.time()
toate=0
bune=0
Fereastra=6
pgram_start=7
pgram_end=9
relatii=[definition,examples,hyponyms]

CachedLineString={}
for syn in SinseturiLinie:
	CachedLineString[MapLine[syn.name()]]=''
for syn in SinseturiLinie:
	CachedLineString[MapLine[syn.name()]]+=CleanStringFromSynset(syn,relatii)+' '
keys=[key for key in CachedLineString]

for Linie in senseval.instances('line.pos'):
	#todo, sa ma uit si la context, daca langa line e un cuv ce poate sa fie si verb si substantiv si in context e substantiv, iau doar pt substantive
	WordsWithSense=[word[0] for word in Linie.context if len(wn.synsets(word[0]))!=0]
	LineIndex= [ps.stem(word) for word in WordsWithSense].index('line')
	Context=[word for word in WordsWithSense[LineIndex-Fereastra:LineIndex+Fereastra +1] if ps.stem(word)!=ps.stem('line')]
	ContextStr=CleanStringFromContext(Context,relatii)
	Similar=[Similaritate(ContextStr, CachedLineString[key],pgram_start,pgram_end) for key in CachedLineString]
	indexSyn=np.argmax(Similar)
	pred=keys[indexSyn]
	if(Linie.senses[0]==pred):
		bune+=1
	toate+=1
	if(toate%400==0):
		print(bune/toate,' time:',time.time() - start_time,' ',Fereastra,' ',pgram_start,' ',pgram_end,' ',relatii)
	# print(round(100.0*toate/nrLinii),'% done ,time:',time.time() - start_time,' ',Linie.senses[0],'->',pred,' acc: ',100.0*bune/toate)
print(bune/toate,' time:',time.time() - start_time,' ',Fereastra,' ',pgram_start,' ',pgram_end,' ',relatii)

exit(0)

# Str="Such a trading strategy would ordinarily be a prescription for instant losses. </s> @ <s> But the trader says he was merely following instructions from his client -- a Fed dealer on the other end of a dedicated private telephone line."
# Words=CleanString(Str)
# WordsWithSense=[word for word in Words if len(wn.synsets(word[0]))!=0]
# LineIndex= [ps.stem(word) for word in WordsWithSense].index('line')
# Context=[word for word in WordsWithSense[LineIndex-3:LineIndex+3 +1] if ps.stem(word)!=ps.stem('line')]

# ContextStr=ConcatWordsDefinitionsAndExamples(Context)
# ContextStr=' '.join(CleanString(ContextStr))

# Similar=[Similaritate(ContextStr, CleanStringFromSynset(syn)	) for syn in SinseturiLinie]
# indexSyn=np.argmax(Similar)
# 


def ShowBar(List):
	index = np.arange(len(List))
	plt.bar(index, List)
	plt.show()




def GetCommonPair(A,B):
	ret=0
	for pair in A.keys():
		if(B[pair]!=0):
			return pair
	return ''
def GetBiggestPair(A,B):
	best=''
	for i in range(1,115):
		k=GetCommonPair(Text2Pgrams(A,i),Text2Pgrams(B,i))
		if(k!=''):
			best=k
		else:
			return best
	return ''	

	
def DeCe(String,ListaString):
	return [GetBiggestPair(String,str) for str in ListaString]
	

	
nrLinii=len(senseval.instances('line.pos'))

	

#combinatii de relatii
#pgrame 1-20
import time


fout = open(str(time.time()),'w')

for Fereastra in range(3,8):#Fereastra intre 1 si 7
	for pgram_start in range(4,20,3):
		for pgram_end in range(pgram_start+2,20,3):
			for m in range(1,len(relations)+1):
				for relatii in findsubsets(relations,m):
					relatii=[definition,examples]+list(relatii)
					CachedLineString={}
					for syn in SinseturiLinie:
						CachedLineString[MapLine[syn.name()]]=''
					for syn in SinseturiLinie:
						CachedLineString[MapLine[syn.name()]]+=CleanStringFromSynset(syn,relatii)+' '
					keys=[key for key in CachedLineString]

		

					start_time = time.time()
					toate=0
					bune=0

					for Linie in senseval.instances('line.pos'):
						#todo, sa ma uit si la context, daca langa line e un cuv ce poate sa fie si verb si substantiv si in context e substantiv, iau doar pt substantive
						WordsWithSense=[word[0] for word in Linie.context if len(wn.synsets(word[0]))!=0]
						LineIndex= [ps.stem(word) for word in WordsWithSense].index('line')
						Context=[word for word in WordsWithSense[LineIndex-Fereastra:LineIndex+Fereastra +1] if ps.stem(word)!=ps.stem('line')]
						ContextStr=CleanStringFromContext(Context,relatii)
						Similar=[Similaritate(ContextStr, CachedLineString[key],pgram_start,pgram_end) for key in CachedLineString]
						indexSyn=np.argmax(Similar)
						pred=keys[indexSyn]
						if(Linie.senses[0]==pred):
							bune+=1
						toate+=1
						# if(toate%400==0):
							# print(round(100.0*toate/nrLinii),'% done ,time:',time.time() - start_time,' ',Linie.senses[0],'->',pred,' acc: ',100.0*bune/toate)
						# print(round(100.0*toate/nrLinii),'% done ,time:',time.time() - start_time,' ',Linie.senses[0],'->',pred,' acc: ',100.0*bune/toate)
					print(bune/toate,' time:',time.time() - start_time,' ',Fereastra,' ',pgram_start,' ',pgram_end,' ',relatii)
					print(bune/toate,' time:',time.time() - start_time,' ',Fereastra,' ',pgram_start,' ',pgram_end,' ',relatii, file=fout)
					fout.flush()






exit(0)


# TelSyn=GoodSyns[14]



# SynseturiContext=[]
# for word in Context:
	# for syn in wn.synsets(word):
		# SynseturiContext.append(syn)
# SynsetLinie=[TelSyn]+TelSyn.hyponyms()+TelSyn.hypernyms()


# for FSimilar in [Similar1,Similar2,Similar3,Similar4,Similar5,Similar6]:
	# for FMMM in [Mean,Max]:
		# print( DistanceFrom2ListOfSynset(SynseturiContext,SynsetLinie,FMMM,FSimilar) )
		# distances=[]
		# for syn in GoodSyns:
			# SynsetLinie=[syn]+syn.hyponyms()+syn.hypernyms()
			# distances.append(DistanceFrom2ListOfSynset(SynseturiContext,SynsetLinie,FMMM,FSimilar))
		# indexSyn=np.argmin(distances)
		# print(indexSyn==14)



# STRSYN=TelSyn.definition()+' '+(' '.join(TelSyn.examples()))

# AltuSyn=GoodSyns[0]
# STRSYN2=AltuSyn.definition()+' '+(' '.join(AltuSyn.examples()))


# Similaritate(Str,STRSYN)
# Similaritate(Str,STRSYN2)

# exit(0)











# Cate=len(senseval.instances('line.pos'))


# nrLinii=len(senseval.instances('line.pos'))


# synseturi=wn.synsets('line')
# # synseturi=[syn for syn in synseturi if syn.name() in MapLine]

# for FSimilar in [Similar1,Similar2,Similar3,Similar4,Similar5,Similar6]:
# # for FSimilar in [Distance1]:
	# for FMMM in [Mean,Max]:
		# start_time = time.time()
		# print(FMMM,FSimilar)
		# toate=0
		# bune=0
		# for Linie in senseval.instances('line.pos'):
			# index=StringVsSynsets(Linie,synseturi,FMMM,FSimilar)
			
			# pred='gresit'
			# if index in MapLine:
				# pred=MapLine[index]
			# # print(100.0*i/Cate,'% ',Linie.senses[0],'->',pred)
			# if(Linie.senses[0]==pred):
				# bune+=1
			# toate+=1
			# if(toate%400==0):
				# print(round(100.0*toate/nrLinii),'% done ,time:',time.time() - start_time,' ',Linie.senses[0],'->',pred,' acc: ',100.0*bune/toate)
		# print(round(100.0*toate/nrLinii),'% done ,time:',time.time() - start_time,' ',Linie.senses[0],'->',pred,' acc: ',100.0*bune/toate)



